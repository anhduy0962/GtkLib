#!/bin/sh

# these bindings are for the dbus-glib implementation of prog_present
# gio's GDBus has the introspection data in the code itself
dbus-binding-tool --mode=glib-server --output=prog-presenter-glue.h --prefix=cgu_prog_presenter prog-presenter.xml
dbus-binding-tool --mode=glib-client --output=prog-presenter-bindings.h prog-presenter.xml
