#ifndef CGU_CONFIG_H
#define CGU_CONFIG_H

/* 
 * This file is produced from cgu_config.h.in by the ./configure
 * script.
 */

#undef CGU_USE_GLIB_MEMORY_SLICES_COMPAT
#undef CGU_USE_GLIB_MEMORY_SLICES_NO_COMPAT

/* 
 * None of these new operators throw std::bad_alloc as glib terminates
 * the whole application if it cannot allocate memory.
 *
 * These functions are only suitable as class member functions,
 * because they do not check whether the passed size request value is
 * 0, and g_slice_alloc() will not allocate any memory if passed a
 * size of 0.  (A class allocator will not be passed a size value less
 * than 1 as an empty class/struct object has sizeof 1 in C++, so
 * these will always be safe as member functions.)
 *
 * For anyone porting this library to windows, operator new[]() and
 * operator delete[]() for arrays should not be included, because
 * Visual Studio does not correctly comply with the C++ standard with
 * respect to the two argument version of operator delete[]().
 */
#if defined(CGU_USE_GLIB_MEMORY_SLICES_COMPAT) || defined(CGU_USE_GLIB_MEMORY_SLICES_NO_COMPAT)
#include <new>
#include <cstdlib>
#include <glib.h>
#define CGU_GLIB_MEMORY_SLICES_FUNCS \
static void* operator new(std::size_t s) {return g_slice_alloc(s);} \
static void* operator new(std::size_t s, const std::nothrow_t&) {return g_slice_alloc(s);} \
static void* operator new(std::size_t s, void* p) {return ::operator new(s, p);} \
static void operator delete(void* p, std::size_t s) {if (p) g_slice_free1(s, p);} \
static void operator delete(void* p, std::size_t s, const std::nothrow_t&) {if (p) g_slice_free1(s, p);} \
static void operator delete(void* p, void* q) {::operator delete(p, q);} \
static void* operator new[](std::size_t s) {return g_slice_alloc(s);} \
static void* operator new[](std::size_t s, const std::nothrow_t&) {return g_slice_alloc(s);} \
static void* operator new[](std::size_t s, void* p) {return ::operator new[](s, p);} \
static void operator delete[](void* p, std::size_t s) {if (p) g_slice_free1(s, p);} \
static void operator delete[](void* p, std::size_t s, const std::nothrow_t&) {if (p) g_slice_free1(s, p);} \
static void operator delete[](void* p, void* q) {return ::operator delete[](p, q);}
#else
#define CGU_GLIB_MEMORY_SLICES_FUNCS // Using global operator new, new[], delete and delete[]
#endif

/* This determines whether each of the library headers will contain a
   'using namespace Cgu' directive. It will include such a using
   directive if configure is passed the --with-cgu-using-directive
   option.  (It can also be edited by hand.)
*/
namespace Cgu {}
// do not include using directive

/* whether the system provides sched_yield */
#define CGU_USE_SCHED_YIELD 1

/* whether the system was found to provide working recursive mutexes
   when the library was compiled
*/
#define CGU_HAVE_RECURSIVE_MUTEX 1

/* whether ==, != and < operators to be available for smart pointers */
#define CGU_USE_SMART_PTR_COMPARISON 1

/* whether the std::queue implementation is standard conforming and
   inheritable */
#define CGU_USE_INHERITABLE_QUEUE 1

/* whether the library is to be compiled with GTK+ support */
#define CGU_USE_GTK 3

/* whether the library is to be compiled with support for guile
   extensions */
#define CGU_USE_GUILE 1

/* whether guile correctly links scm_dynwind_block_asyncs() */
#undef CGU_GUILE_HAS_BROKEN_LINKING

/* whether to use std::tuple implementation of callback classes */
#define CGU_USE_TUPLE 1

/* indicates that the series of the library being compiled against
   is series 2.2
*/
#define CGU_API_VERSION 22

#endif // CGU_CONFIG_H
