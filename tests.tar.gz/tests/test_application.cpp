#include <c++-gtk-utils/cgu_config.h> // for CGU_USE_GTK

#if CGU_USE_GTK == 3
#define GDK_VERSION_MIN_REQUIRED GDK_VERSION_3_0
#elif CGU_USE_GTK == 4
#define GDK_VERSION_MIN_REQUIRED GDK_VERSION_4_0
#endif

#include <glib.h>
#include <gtk/gtk.h>
#include <utility>

#if GTK_CHECK_VERSION(2,99,0)
#include <c++-gtk-utils/application.h>
#endif

#include <c++-gtk-utils/window.h>
#include <c++-gtk-utils/callback.h>

using namespace Cgu;

class Message: public Cgu::WinBase {
public:
  void pub_close() {close();}
  Message(const char* text);
};

Message::Message(const char* text): WinBase{"Message", 0, false} {
#if GTK_CHECK_VERSION(3,90,0)
  GtkWidget* box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 2);
  gtk_box_set_homogeneous(GTK_BOX(box), false);
  gtk_container_add(GTK_CONTAINER(get_win()), box);
  GtkWidget* label = gtk_label_new(text);
  gtk_widget_set_vexpand(label, true);
  gtk_widget_set_valign(label, GTK_ALIGN_CENTER);
  gtk_box_pack_start(GTK_BOX(box), label);
  GtkWidget* button_box = gtk_button_box_new(GTK_ORIENTATION_HORIZONTAL);
  gtk_widget_set_valign(button_box, GTK_ALIGN_CENTER);
  gtk_box_pack_start(GTK_BOX(box), button_box);
#elif GTK_CHECK_VERSION(3,4,0)
  GtkWidget* box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 2);
  gtk_box_set_homogeneous(GTK_BOX(box), false);
  gtk_container_add(GTK_CONTAINER(get_win()), box);
  GtkWidget* label = gtk_label_new(text);
  gtk_box_pack_start(GTK_BOX(box), label,
		     true, false, 0);
  GtkWidget* button_box = gtk_button_box_new(GTK_ORIENTATION_HORIZONTAL);
  gtk_box_pack_start(GTK_BOX(box), button_box,
		     false, false, 0);
#else
  GtkWidget* box = gtk_vbox_new(false, 2);
  gtk_container_add(GTK_CONTAINER(get_win()), box);
  GtkWidget* label = gtk_label_new(text);
  gtk_box_pack_start(GTK_BOX(box), label,
                     true, false, 0);
  GtkWidget* button_box = gtk_hbutton_box_new();
  gtk_box_pack_start(GTK_BOX(box), button_box,
                     false, false, 0);
#endif
  GtkWidget* button = gtk_button_new_with_label("OK");
  gtk_container_add(GTK_CONTAINER(button_box), button);
  gtk_widget_set_can_default(button, true);
}

#if GTK_CHECK_VERSION(2,99,0)
void app_activate(bool& success, Application* app) {
  Message* dialog = new Message("Test");
  app->add(dialog);
  gtk_widget_realize(GTK_WIDGET(dialog->get_win()));
  g_assert_cmpuint(app->get_win_count(), ==, 1U);
  success = true;

  // make Cgu::Application::run() unblock
  Callback::post(Callback::make(*dialog, &Message::pub_close));
}

void app_command(bool& success, Application* app, GApplicationCommandLine* cl, gint&) {
  Message* dialog = new Message("Test");
  app->add(dialog);
  gtk_widget_realize(GTK_WIDGET(dialog->get_win()));
  g_assert_cmpuint(app->get_win_count(), ==, 1U);
  success = true;

  // make Cgu::Application::run() unblock
  Callback::post(Callback::make(*dialog, &Message::pub_close));
}

void app_open(bool& success, Application* app, std::pair<GFile**, gint> files, gchar*) {
  Message* dialog = new Message("Test");
  app->add(dialog);
  gtk_widget_realize(GTK_WIDGET(dialog->get_win()));
  g_assert_cmpuint(app->get_win_count(), ==, 1U);
  success = true;

  // make Cgu::Application::run() unblock
  Callback::post(Callback::make(*dialog, &Message::pub_close));
}
#endif // GTK_CHECK_VERSION

extern "C" {

static void test_application_window() {
  Message dialog("Test");
  GtkWidget* w = GTK_WIDGET(dialog.get_win());
  gtk_widget_realize(w);
#if GTK_CHECK_VERSION(2,20,0)
  g_assert_cmpuint((unsigned int)gtk_widget_get_realized(w), !=, 0);
#else
  g_assert_cmpuint(((unsigned int)GTK_WIDGET_REALIZED(w)), !=, 0);
#endif

  // make Cgu::Application::run() unblock
  Callback::post(Callback::make(dialog, &Message::pub_close));
  dialog.exec();
}

#if GTK_CHECK_VERSION(2,99,0)
static void test_application_activate() {
  Application app{"test_prog1", G_APPLICATION_FLAGS_NONE};
  bool success = false;
  app.activate.connect(Callback::make<bool&>(app_activate, success));
  app.run(0, 0);
  g_assert_cmpuint((unsigned int)success, !=, 0);
}

static void test_application_command() {
  Application app{"test_prog2", G_APPLICATION_HANDLES_COMMAND_LINE};
  bool success = false;
  app.command_line.connect(Callback::make<bool&>(app_command, success));
  app.run(0, 0);
  g_assert_cmpuint((unsigned int)success, !=, 0);
}

static void test_application_open() {
  Application app{"test_prog3", G_APPLICATION_HANDLES_OPEN};
  bool success = false;
  app.open.connect(Callback::make<bool&>(app_open, success));
  char* args[] = {(char*)"test_application", (char*)"test"};
  app.run(2, args);
  g_assert_cmpuint((unsigned int)success, !=, 0);
}
#endif // GTK_CHECK_VERSION
} // extern "C"


int main (int argc, char* argv[]) {

  gtk_test_init(&argc, &argv, static_cast<void*>(0));

  // with GTK+2 just test Cgu::WinBase
  g_test_add_func("/application/window", test_application_window); 

#if GTK_CHECK_VERSION(2,99,0)
  g_test_add_func("/application/activate", test_application_activate); 
  g_test_add_func("/application/command", test_application_command); 
  g_test_add_func("/application/open", test_application_open);
#endif // GTK_CHECK_VERSION

  return g_test_run();  
}
